@file:Suppress("ImplicitThis")

package com.example.catchthekenny

import android.app.Activity
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

@Suppress("ImplicitThis", "ImplicitThis")
class DatabaseHelper(var ctx:Activity):SQLiteOpenHelper(ctx,"GameKenny",null,1) {

    override fun onCreate(db: SQLiteDatabase?) {
        var qry = "CREATE TABLE user (name TEXT,score INTEGER)"
        db?.execSQL(qry)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }

    fun insertUser(user:User):Long
    {
        var db = writableDatabase
        var cv = ContentValues()
        cv.put("name",user.nm)
        cv.put("score",user.score)
        var res = db.insert("user",null,cv)
        return res
    }

    fun fetchUser(nm:String):Int
    {
        var s = 0
        var n:String = ""
        var db = readableDatabase
        var cr = db.rawQuery("SELECT * FROM user WHERE name = '"+ nm +"'",null)
        while(cr.moveToNext())
        {
            n = cr.getString(0)
            s = cr.getInt(1)
        }
        return s
    }

    fun updateUser(user: User):Int
    {
        var db = writableDatabase
        var cv = ContentValues()
        cv.put("score",user.score)
        var res = db.update("user",cv, "name = '"+ user.nm +"'",null)
        return res
    }
}