package com.example.catchthekenny

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_display_score.*

class DisplayScoreActivity : AppCompatActivity() {

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_score)

        var sp = getSharedPreferences("Login", Context.MODE_APPEND)
        var nm= sp.getString("nm","Player1")
        var dh = DatabaseHelper(this)
        var hs = dh.fetchUser(nm.toString())
        var s = intent.getIntExtra("score",0)
//        Toast.makeText(this,"$s , $hs",Toast.LENGTH_SHORT).show()
        if(s < hs)
        {
            lblHigh.text = "High Score : "+ hs
            lblScore.text = "Your Score : "+ s
        }
        else
        {
            var user = User(nm.toString(),s.toInt())
            var dh = DatabaseHelper(this)
            var res = dh.updateUser(user)
            if(res > 0)
            {
                lblHigh.text = "High Score : "+ s
                lblScore.text = "Your Score : "+ s
            }
            else
            {
                Toast.makeText(this,"Error!",Toast.LENGTH_SHORT).show()
            }
        }

        btnrestart.setOnClickListener {
            var intent1 = Intent(this,HomeActivity::class.java)
            startActivity(intent1)
            finish()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.appbar_menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    @SuppressLint("WrongConstant")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var sp = getSharedPreferences("Login", Context.MODE_APPEND)
        var nm = sp.getString("nm","")
        var edt = sp.edit()
        var id = item.itemId
        if(id == R.id.logout)
        {
            edt.clear()
            edt.commit()
            var intent1 = Intent(this,UserActivity::class.java)
            startActivity(intent1)
            finish()
        }
        return super.onOptionsItemSelected(item)
    }
}
