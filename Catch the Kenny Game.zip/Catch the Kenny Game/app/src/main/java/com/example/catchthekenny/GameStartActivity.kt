package com.example.catchthekenny

import android.annotation.SuppressLint
import android.content.Context
import android.content.Context.MODE_APPEND
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.IntegerRes
import androidx.core.os.postDelayed
import kotlinx.android.synthetic.main.activity_game_start.*
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.timer

class GameStartActivity : AppCompatActivity() {

    @SuppressLint("WrongConstant")
    var point = 0
    var imgArray = ArrayList<ImageView>()
    var handler = Handler()
    var runnable = Runnable {  }
    lateinit var s:String
    var v:Long = 0
    var t:Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_start)

        imgArray = arrayListOf(imageView1, imageView2, imageView3, imageView4, imageView5, imageView6, imageView7, imageView8
            , imageView9, imageView10, imageView11, imageView12, imageView13, imageView14, imageView15, imageView16
            , imageView17, imageView18, imageView19, imageView20)
        point = 0
        hideImg()
        randomImg()
        var tm = intent.getStringExtra("time")
        t = tm.toLong() + 1
        t *= 1000
//        var v = Integer.parseInt(s)
//        v *= 100
//        Toast.makeText(this,v.toString(),Toast.LENGTH_SHORT).show()

        object : CountDownTimer(t, 1000) {
            override fun onFinish() {
                hideImg()
                handler.removeCallbacks(runnable)
                timerText.text = "Time's Off"
                val intent1 = Intent(this@GameStartActivity,DisplayScoreActivity::class.java)
                intent1.putExtra("score",point)
                startActivity(intent1)
                finish()
            }

            override fun onTick(millisUntilFinished: Long) {
                var t = millisUntilFinished / 1000
                timerText.text = "Timer : " + t
                if(t <= 10)
                {
                    timerText.setTextColor(Color.RED)
                }
            }
        }.start()
    }

    fun randomImg(){
        var lvl = fetchLevel()
        runnable = object: Runnable {
            override fun run() {
                hideImg()
                val random = Random()
                val ind = random.nextInt(19-0)
                imgArray[ind].visibility = View.VISIBLE
                handler.postDelayed(runnable, lvl)
            }
        }
        handler.post(runnable)
    }

    fun hideImg() {
        for (img in imgArray) {
            img.visibility = View.INVISIBLE
        }
    }

    fun fetchLevel():Long{
        s = intent.getStringExtra("lvl")
        if(s == "1"){
            v = 800
        }
        else if(s == "2"){
            v = 700
        }
        else if(s == "3"){
            v = 600
        }
        else if(s == "4"){
            v = 500
        }
        else if(s == "5"){
            v = 450
        }
        else if(s == "6"){
            v = 400
        }
        else if(s == "7"){
            v = 350
        }
        else if(s == "8"){
            v = 300
        }
        else if(s == "9"){
            v = 250
        }
        else if(s == "10"){
            v = 200
        }
        return v
    }

    @SuppressLint("ResourceAsColor")
    fun increaseScore(view: View) {
        point += 1
        scoreText.text = "Score : " + point
        if(point > 0)
        {
            // Green Color Code (124,252,0)  (127,255,0)
            scoreText.setTextColor(Color.rgb(41,202,48))
        }
        else
        {
            scoreText.setTextColor(Color.RED)
        }
    }
}
