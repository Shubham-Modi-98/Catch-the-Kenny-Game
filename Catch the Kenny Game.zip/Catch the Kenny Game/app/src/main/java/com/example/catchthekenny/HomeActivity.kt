package com.example.catchthekenny

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_home.*
import java.util.*
import kotlin.collections.ArrayList

class HomeActivity : AppCompatActivity() {

    var arlist = ArrayList<String>()
    var arTime = ArrayList<String>()

    @ExperimentalStdlibApi
    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        var sp = getSharedPreferences("Login", Context.MODE_APPEND)
        var nm= sp.getString("nm","Player1")
        arlist = arrayListOf("Select Level...","1","2","3","4","5","6","7","8","9","10")
        arTime = arrayListOf("Select Level...","20","30","60","90")
        var adp = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arlist)
        var adp1 = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arTime)
        spLevel.adapter = adp
        spTimer.adapter = adp1
        var s = 0
        var t = 0
//        var v = "0"

        if (nm != null) {
            lblName.text = "HELLO, "+nm.toUpperCase()
        }
        spLevel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                s =  position
            }
        }
        spTimer.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                t =  position
            }
        }
        btnPlay.setOnClickListener {
            if(s  == 0 || t == 0){
                if (s == 0 && t == 0) {
                    Toast.makeText(this,"Select Level and Time",Toast.LENGTH_SHORT).show()
                }
                else if (s == 0) {
                    Toast.makeText(this,"Select Level",Toast.LENGTH_SHORT).show()
                }
                else if (t == 0) {
                    Toast.makeText(this,"Select Time",Toast.LENGTH_SHORT).show()
                }
            }
            else{
//                v = arlist[s]
//                Toast.makeText(this,"$v",Toast.LENGTH_SHORT).show()
                var intent1 = Intent(this,GameStartActivity::class.java)
                intent1.putExtra("lvl",arlist[s])
                intent1.putExtra("time",arTime[t])
                startActivity(intent1)
                finish()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.appbar_menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    @SuppressLint("WrongConstant")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var sp = getSharedPreferences("Login", Context.MODE_APPEND)
        var nm = sp.getString("nm","")
        var edt = sp.edit()
        var id = item.itemId
        if(id == R.id.logout)
        {
            edt.clear()
            edt.commit()
            var intent1 = Intent(this,UserActivity::class.java)
            startActivity(intent1)
            finish()
        }
        return super.onOptionsItemSelected(item)
    }
}
