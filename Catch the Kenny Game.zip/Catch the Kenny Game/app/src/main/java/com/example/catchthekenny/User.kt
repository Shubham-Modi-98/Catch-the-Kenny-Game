package com.example.catchthekenny

data class User(var nm:String, var score:Int) {

}