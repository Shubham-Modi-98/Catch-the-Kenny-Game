package com.example.catchthekenny

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_user.*

class UserActivity : AppCompatActivity() {

    lateinit var nm:String
    var score:Int = 0

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        var sp = getSharedPreferences("Login", Context.MODE_APPEND)
        var user = sp.getString("nm","")
        if(user == "")
        {
            btnLogin.setOnClickListener {
                nm = txtName.text.toString()
                if(nm != ""){
                    //Toast.makeText(this,nm,Toast.LENGTH_SHORT).show()
                    var user = User(nm, score)
                    var db = DatabaseHelper(this)
                    var res = db.insertUser(user)
                    var edt = sp.edit()
                    if(res > 0) {
                        edt.putString("nm",nm)
                        edt.commit()
                        var intent1 = Intent(applicationContext,HomeActivity::class.java)
                        startActivity(intent1)
                        finish()
//                        Toast.makeText(this,"$res ,Success",Toast.LENGTH_SHORT).show()
                    }
                    else{
                        Toast.makeText(this,"Error in Login",Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this,"Please Enter Name First",Toast.LENGTH_SHORT).show()
                }
            }
        }
        else
        {
            var intent1 = Intent(applicationContext,HomeActivity::class.java)
            startActivity(intent1)
            finish()
        }
    }
}
